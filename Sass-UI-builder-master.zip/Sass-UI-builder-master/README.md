# SASS Boilerplate
SASS Boilerplate is a front-end template for building fast,
robust, and adaptable web sites.

##Features

* [Bootstrap](http://getbootstrap.com/) Grid.
*  Built with the power of [Sass](http://sass-lang.com/).
*  Cross-browser compatible (Chrome, Firefox, IE9+, Opera, Safari).


